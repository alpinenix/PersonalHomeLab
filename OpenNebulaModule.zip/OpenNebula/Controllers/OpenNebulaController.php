<?php
namespace Modules\OpenNebula\Controllers;

use Illuminate\Http\Request;
use Modules\OpenNebula\Services\OpenNebulaAPI;

class OpenNebulaController
{
    public function create(Request $request)
    {
        $api = app('OpenNebulaAPI');
        $vm = $api->createVPS($request->template_id, $request->vm_name);
        return response()->json(['vm_id' => $vm[1]]);
    }

    public function delete(Request $request)
    {
        $api = app('OpenNebulaAPI');
        $api->deleteVPS($request->vm_id);
        return response()->json(['status' => 'deleted']);
    }

    public function update(Request $request)
    {
        $api = app('OpenNebulaAPI');
        $api->updateVPS($request->vm_id, $request->cpu, $request->ram);
        return response()->json(['status' => 'updated']);
    }
}
