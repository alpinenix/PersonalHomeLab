<?php
namespace Modules\OpenNebula\Services;

class OpenNebulaAPI
{
    protected $url;
    protected $user;
    protected $pass;

    public function __construct($url, $user, $pass)
    {
        $this->url  = $url;
        $this->user = $user;
        $this->pass = $pass;
    }

    protected function call($method, $params = [])
    {
        $client = new \SoapClient(null, [
            'location' => $this->url,
            'uri' => 'http://opennebula.org/',
        ]);
        return $client->__soapCall($method, array_merge([$this->user . ':' . $this->pass], $params));
    }

    public function createVPS($templateId, $name)
    {
        return $this->call('one.vm.allocate', [$templateId, $name]);
    }

    public function deleteVPS($vmId)
    {
        return $this->call('one.vm.action', ['delete', $vmId]);
    }

    public function updateVPS($vmId, $cpu, $ram)
    {
        return $this->call('one.vm.updateconf', [$vmId, "<CPU>$cpu</CPU><MEMORY>$ram</MEMORY>", 1]);
    }
}
