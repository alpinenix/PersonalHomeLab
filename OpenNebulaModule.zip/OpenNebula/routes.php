<?php
use Illuminate\Support\Facades\Route;
use Modules\OpenNebula\Controllers\OpenNebulaController;

Route::prefix('opennebula')->group(function () {
    Route::post('create', [OpenNebulaController::class, 'create']);
    Route::post('delete', [OpenNebulaController::class, 'delete']);
    Route::post('update', [OpenNebulaController::class, 'update']);
});
