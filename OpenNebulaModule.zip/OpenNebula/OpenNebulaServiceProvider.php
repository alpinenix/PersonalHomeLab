<?php
namespace Modules\OpenNebula;

use Illuminate\Support\ServiceProvider;

class OpenNebulaServiceProvider extends ServiceProvider
{
    public function boot()
    {
        include __DIR__.'/routes.php';
    }

    public function register()
    {
        $this->app->bind('OpenNebulaAPI', function () {
            return new \Modules\OpenNebula\Services\OpenNebulaAPI(
                env('OPENNEBULA_URL'),
                env('OPENNEBULA_USER'),
                env('OPENNEBULA_PASS')
            );
        });
    }
}
